import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const leagues = pgTable("leagues", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  country: text("country").notNull(),
  logoUrl: text("logo_url"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  logoUrl: text("logo_url"),
  leagueId: varchar("league_id").references(() => leagues.id),
  marketValue: decimal("market_value", { precision: 12, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const matches = pgTable("matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  homeTeamId: varchar("home_team_id").notNull().references(() => teams.id),
  awayTeamId: varchar("away_team_id").notNull().references(() => teams.id),
  leagueId: varchar("league_id").notNull().references(() => leagues.id),
  kickoffTime: timestamp("kickoff_time").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, live, finished
  homeScore: integer("home_score"),
  awayScore: integer("away_score"),
  homeXg: decimal("home_xg", { precision: 4, scale: 2 }),
  awayXg: decimal("away_xg", { precision: 4, scale: 2 }),
  homeCorners: integer("home_corners"),
  awayCorners: integer("away_corners"),
  homeCards: integer("home_cards"),
  awayCards: integer("away_cards"),
  possession: json("possession"), // {home: 65, away: 35}
  weatherConditions: text("weather_conditions"),
  venue: text("venue"),
  attendance: integer("attendance"),
  referee: text("referee"),
  importance: decimal("importance", { precision: 3, scale: 1 }), // 1-10 scale
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const predictions = pgTable("predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  matchId: varchar("match_id").notNull().references(() => matches.id),
  predictionType: text("prediction_type").notNull(), // match_result, over_under, btts, corners, cards
  outcome: text("outcome").notNull(), // home_win, away_win, draw, over, under, yes, no
  confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(),
  probability: decimal("probability", { precision: 5, scale: 2 }).notNull(),
  modelVersion: text("model_version").notNull(),
  features: json("features"), // feature importance data
  explanation: text("explanation"),
  expectedValue: decimal("expected_value", { precision: 5, scale: 2 }),
  riskLevel: text("risk_level"), // low, medium, high
  marketVolume: decimal("market_volume", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const odds = pgTable("odds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  matchId: varchar("match_id").notNull().references(() => matches.id),
  bookmaker: text("bookmaker").notNull(),
  homeOdds: decimal("home_odds", { precision: 4, scale: 2 }),
  drawOdds: decimal("draw_odds", { precision: 4, scale: 2 }),
  awayOdds: decimal("away_odds", { precision: 4, scale: 2 }),
  overUnder25Odds: json("over_under_25_odds"), // {over: 1.85, under: 1.95}
  bttsOdds: json("btts_odds"), // {yes: 1.75, no: 2.05}
  cornersOdds: json("corners_odds"), // {over9: 1.90, under9: 1.90}
  cardsOdds: json("cards_odds"), // {over3: 1.80, under3: 2.00}
  asianHandicap: json("asian_handicap"), // {home: -1.5, away: +1.5, odds: [1.85, 1.95]}
  doubleChance: json("double_chance"), // {homeOrDraw: 1.25, awayOrDraw: 1.75, homeOrAway: 1.10}
  marketDepth: decimal("market_depth", { precision: 10, scale: 2 }),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const teamStats = pgTable("team_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id),
  season: text("season").notNull(),
  matchesPlayed: integer("matches_played").default(0),
  wins: integer("wins").default(0),
  draws: integer("draws").default(0),
  losses: integer("losses").default(0),
  goalsFor: integer("goals_for").default(0),
  goalsAgainst: integer("goals_against").default(0),
  xgFor: decimal("xg_for", { precision: 5, scale: 2 }),
  xgAgainst: decimal("xg_against", { precision: 5, scale: 2 }),
  recentForm: text("recent_form"), // "WWLDW"
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const injuries = pgTable("injuries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id),
  playerName: text("player_name").notNull(),
  injuryType: text("injury_type"),
  expectedReturn: timestamp("expected_return"),
  impact: text("impact"), // high, medium, low
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const leaguesRelations = relations(leagues, ({ many }) => ({
  teams: many(teams),
  matches: many(matches),
}));

export const teamsRelations = relations(teams, ({ one, many }) => ({
  league: one(leagues, {
    fields: [teams.leagueId],
    references: [leagues.id],
  }),
  homeMatches: many(matches, { relationName: "homeTeam" }),
  awayMatches: many(matches, { relationName: "awayTeam" }),
  stats: many(teamStats),
  injuries: many(injuries),
}));

export const matchesRelations = relations(matches, ({ one, many }) => ({
  homeTeam: one(teams, {
    fields: [matches.homeTeamId],
    references: [teams.id],
    relationName: "homeTeam",
  }),
  awayTeam: one(teams, {
    fields: [matches.awayTeamId],
    references: [teams.id],
    relationName: "awayTeam",
  }),
  league: one(leagues, {
    fields: [matches.leagueId],
    references: [leagues.id],
  }),
  predictions: many(predictions),
  odds: many(odds),
}));

export const predictionsRelations = relations(predictions, ({ one }) => ({
  match: one(matches, {
    fields: [predictions.matchId],
    references: [matches.id],
  }),
}));

export const oddsRelations = relations(odds, ({ one }) => ({
  match: one(matches, {
    fields: [odds.matchId],
    references: [matches.id],
  }),
}));

export const teamStatsRelations = relations(teamStats, ({ one }) => ({
  team: one(teams, {
    fields: [teamStats.teamId],
    references: [teams.id],
  }),
}));

export const injuriesRelations = relations(injuries, ({ one }) => ({
  team: one(teams, {
    fields: [injuries.teamId],
    references: [teams.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertLeagueSchema = createInsertSchema(leagues).omit({
  id: true,
  createdAt: true,
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  createdAt: true,
});

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({
  id: true,
  createdAt: true,
});

export const insertOddsSchema = createInsertSchema(odds).omit({
  id: true,
  updatedAt: true,
});

export const insertTeamStatsSchema = createInsertSchema(teamStats).omit({
  id: true,
  updatedAt: true,
});

export const insertInjurySchema = createInsertSchema(injuries).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type League = typeof leagues.$inferSelect;
export type InsertLeague = z.infer<typeof insertLeagueSchema>;
export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Match = typeof matches.$inferSelect;
export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Odds = typeof odds.$inferSelect;
export type InsertOdds = z.infer<typeof insertOddsSchema>;
export type TeamStats = typeof teamStats.$inferSelect;
export type InsertTeamStats = z.infer<typeof insertTeamStatsSchema>;
export type Injury = typeof injuries.$inferSelect;
export type InsertInjury = z.infer<typeof insertInjurySchema>;

// Extended types for API responses
export type MatchWithDetails = Match & {
  homeTeam: Team;
  awayTeam: Team;
  league: League;
  predictions: Prediction[];
  odds: Odds[];
  homeTeamStats?: TeamStats;
  awayTeamStats?: TeamStats;
};

export type PredictionWithMatch = Prediction & {
  match: MatchWithDetails;
};
