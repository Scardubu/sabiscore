# Overview

This is a production-ready sports betting insights platform that generates calibrated, explainable predictions for upcoming fixtures across the top 6 football leagues. The system combines advanced web scraping, machine learning predictions, and real-time odds tracking to deliver high-confidence betting insights with full explainability.

The platform operates as a full-stack application with automated data collection, ML-powered prediction generation, and a modern dashboard for visualizing betting opportunities. It emphasizes stealth scraping practices and production-grade architecture for reliable, scalable operation.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built with React 18 and TypeScript, using Vite for development and bundling. The UI leverages shadcn/ui components with Radix UI primitives for accessibility, styled with Tailwind CSS using a dark sports betting theme. State management is handled through TanStack Query for server state and React hooks for local state. The application uses Wouter for lightweight client-side routing and implements responsive design patterns optimized for desktop and mobile viewing.

## Backend Architecture  
The server runs on Express.js with TypeScript in ESM mode, following a service-oriented architecture. Core services include:

- **ScrapingService**: Implements stealth web scraping using Playwright with rotating user agents, proxy rotation, and headless browser stealth modes to extract fixture data, odds, team statistics, and injury reports
- **MLService**: Handles machine learning prediction generation with XGBoost models, feature engineering, and confidence scoring for match results, over/under goals, and other betting markets
- **SchedulerService**: Manages automated background tasks for data collection, prediction updates, and system maintenance using configurable intervals

The API follows RESTful conventions with comprehensive error handling, request logging, and health monitoring endpoints.

## Data Storage Solutions
PostgreSQL serves as the primary database, accessed through Drizzle ORM with Neon's serverless driver for connection pooling and performance optimization. The schema supports:

- League and team hierarchies with metadata
- Match scheduling and real-time score updates
- Multi-market prediction storage with confidence metrics and explainability data
- Historical odds tracking from multiple bookmakers
- Team performance statistics and injury databases
- User management and session handling

Database migrations are managed through Drizzle Kit with version control and rollback capabilities.

## Authentication and Authorization
Currently implements a basic user system with username/password authentication. The architecture supports expansion to JWT tokens, OAuth providers, and role-based access control for different user tiers and administrative functions.

## ML Pipeline Architecture
The prediction system implements a two-stage approach:
1. Feature engineering extracts team form, head-to-head records, market values, injury impacts, and statistical indicators
2. Ensemble models (primarily XGBoost) generate calibrated probabilities with confidence intervals and SHAP-based explanations

Model versioning tracks performance metrics and enables A/B testing of different algorithms. The system emphasizes explainable AI with detailed reasoning for each prediction.

## Scraping Infrastructure
Implements production-grade anti-detection measures:
- Dynamic user agent rotation from realistic browser profiles
- Proxy pool management with automatic failover
- Request timing randomization to mimic human behavior  
- Browser fingerprint randomization and stealth mode activation
- Graceful error handling with exponential backoff and circuit breakers

The scraping system targets major football data sources while respecting rate limits and implementing ethical scraping practices.

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling, automated scaling, and branch-based development workflows
- **Drizzle ORM**: Type-safe database access layer with migration management and query optimization

## UI Framework Stack  
- **React 18**: Core frontend framework with concurrent features and modern hooks
- **shadcn/ui**: Complete component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first styling with custom design tokens for sports betting themes
- **Lucide React**: Consistent icon system with sports and analytics iconography

## Development Tools
- **Vite**: Fast development server and optimized production builds
- **TypeScript**: Full type safety across frontend, backend, and shared schemas
- **Playwright**: Browser automation for robust web scraping capabilities
- **ESBuild**: High-performance bundling for server-side deployment

## Data Processing
- **Cheerio**: Server-side HTML parsing and DOM manipulation for scraped content
- **TanStack Query**: Intelligent caching, background updates, and optimistic UI updates
- **Zod**: Runtime schema validation and type inference for API boundaries

## Production Services
- **Replit Deployment**: Integrated hosting with automatic SSL, environment management, and monitoring
- **Compression Middleware**: Response optimization for improved loading performance
- **CORS Configuration**: Secure cross-origin resource sharing for API access

The system is architected for horizontal scaling with clear separation of concerns, comprehensive error handling, and production-ready monitoring capabilities.