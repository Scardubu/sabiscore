import { ScrapingService } from "./scraper";
import { MLService } from "./ml-service";
import type { IStorage } from "../storage";

export class SchedulerService {
  private intervals: NodeJS.Timeout[] = [];
  private running = false;

  constructor(
    private scrapingService: ScrapingService,
    private mlService: MLService,
    private storage: IStorage
  ) {}

  start(): void {
    if (this.running) return;
    
    console.log("[Scheduler] Starting background services...");
    
    // Scrape fixtures every 30 minutes
    const fixtureInterval = setInterval(async () => {
      try {
        await this.scrapingService.scrapeFixtures();
        console.log("[Scheduler] Fixture scraping completed");
      } catch (error) {
        console.error("[Scheduler] Fixture scraping failed:", error);
      }
    }, 30 * 60 * 1000); // 30 minutes

    // Scrape odds every 15 minutes
    const oddsInterval = setInterval(async () => {
      try {
        await this.scrapingService.scrapeOdds();
        console.log("[Scheduler] Odds scraping completed");
      } catch (error) {
        console.error("[Scheduler] Odds scraping failed:", error);
      }
    }, 15 * 60 * 1000); // 15 minutes

    // Update team stats every 6 hours
    const statsInterval = setInterval(async () => {
      try {
        await this.scrapingService.scrapeTeamStats();
        console.log("[Scheduler] Stats scraping completed");
      } catch (error) {
        console.error("[Scheduler] Stats scraping failed:", error);
      }
    }, 6 * 60 * 60 * 1000); // 6 hours

    // Check for injuries every 2 hours
    const injuryInterval = setInterval(async () => {
      try {
        await this.scrapingService.scrapeInjuries();
        console.log("[Scheduler] Injury scraping completed");
      } catch (error) {
        console.error("[Scheduler] Injury scraping failed:", error);
      }
    }, 2 * 60 * 60 * 1000); // 2 hours

    // Generate predictions every hour
    const predictionInterval = setInterval(async () => {
      try {
        await this.generatePredictionsForUpcomingMatches();
        console.log("[Scheduler] Prediction generation completed");
      } catch (error) {
        console.error("[Scheduler] Prediction generation failed:", error);
      }
    }, 60 * 60 * 1000); // 1 hour

    // Calibrate models daily
    const calibrationInterval = setInterval(async () => {
      try {
        await this.mlService.calibrateModel();
        console.log("[Scheduler] Model calibration completed");
      } catch (error) {
        console.error("[Scheduler] Model calibration failed:", error);
      }
    }, 24 * 60 * 60 * 1000); // 24 hours

    this.intervals = [
      fixtureInterval,
      oddsInterval,
      statsInterval,
      injuryInterval,
      predictionInterval,
      calibrationInterval,
    ];

    this.running = true;
    console.log("[Scheduler] All background services started");

    // Initial data population
    this.initialDataLoad();
  }

  stop(): void {
    if (!this.running) return;
    
    console.log("[Scheduler] Stopping background services...");
    
    this.intervals.forEach(interval => clearInterval(interval));
    this.intervals = [];
    this.running = false;
    
    console.log("[Scheduler] All background services stopped");
  }

  isRunning(): boolean {
    return this.running;
  }

  private async initialDataLoad(): Promise<void> {
    console.log("[Scheduler] Starting initial data load...");
    
    try {
      // Create sample leagues if none exist
      await this.ensureBaseData();
      
      // Start scraping process
      await this.scrapingService.scrapeAll();
      
      console.log("[Scheduler] Initial data load completed");
    } catch (error) {
      console.error("[Scheduler] Initial data load failed:", error);
    }
  }

  private async ensureBaseData(): Promise<void> {
    const leagues = await this.storage.getLeagues();
    
    if (leagues.length === 0) {
      console.log("[Scheduler] Creating base leagues...");
      
      const baseLeagues = [
        { name: "Premier League", country: "England", logoUrl: "https://images.unsplash.com/photo-1614632537239-b6df440c1d2e?w=40&h=40" },
        { name: "La Liga", country: "Spain", logoUrl: "https://images.unsplash.com/photo-1577223625816-7546f13df25d?w=40&h=40" },
        { name: "Bundesliga", country: "Germany", logoUrl: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=40&h=40" },
        { name: "Serie A", country: "Italy", logoUrl: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=40&h=40" },
        { name: "Ligue 1", country: "France", logoUrl: "https://images.unsplash.com/photo-1553778263-73a83bab9b0c?w=40&h=40" },
        { name: "Champions League", country: "Europe", logoUrl: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=40&h=40" },
      ];

      for (const league of baseLeagues) {
        await this.storage.createLeague(league);
      }
    }
  }

  private async generatePredictionsForUpcomingMatches(): Promise<void> {
    const upcomingMatches = await this.storage.getUpcomingMatches(50);
    
    for (const match of upcomingMatches) {
      try {
        const existingPredictions = await this.storage.getPredictionsForMatch(match.id);
        
        // Only generate predictions if none exist or they're older than 1 hour
        if (existingPredictions.length === 0) {
          await this.mlService.generatePredictions(match);
        }
      } catch (error) {
        console.error(`[Scheduler] Failed to generate predictions for match ${match.id}:`, error);
      }
    }
  }
}
