import { 
  users, teams, leagues, matches, predictions, odds, teamStats, injuries,
  type User, type InsertUser, type League, type InsertLeague, 
  type Team, type InsertTeam, type Match, type InsertMatch,
  type Prediction, type InsertPrediction, type Odds, type InsertOdds,
  type TeamStats, type InsertTeamStats, type Injury, type InsertInjury,
  type MatchWithDetails
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Leagues
  getLeagues(): Promise<League[]>;
  getLeague(id: string): Promise<League | undefined>;
  createLeague(league: InsertLeague): Promise<League>;

  // Teams
  getTeams(): Promise<Team[]>;
  getTeamsByLeague(leagueId: string): Promise<Team[]>;
  getTeam(id: string): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;

  // Matches
  getUpcomingMatches(limit?: number): Promise<MatchWithDetails[]>;
  getMatchesByLeague(leagueId: string, upcoming?: boolean): Promise<MatchWithDetails[]>;
  getMatch(id: string): Promise<MatchWithDetails | undefined>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatch(id: string, updates: Partial<InsertMatch>): Promise<Match | undefined>;

  // Predictions
  getPredictionsForMatch(matchId: string): Promise<Prediction[]>;
  getHighConfidencePredictions(minConfidence?: number): Promise<Prediction[]>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;

  // Odds
  getOddsForMatch(matchId: string): Promise<Odds[]>;
  createOdds(odds: InsertOdds): Promise<Odds>;
  updateOdds(id: string, updates: Partial<InsertOdds>): Promise<Odds | undefined>;

  // Team Stats
  getTeamStats(teamId: string, season?: string): Promise<TeamStats | undefined>;
  createOrUpdateTeamStats(stats: InsertTeamStats): Promise<TeamStats>;

  // Injuries
  getActiveInjuries(teamId: string): Promise<Injury[]>;
  createInjury(injury: InsertInjury): Promise<Injury>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getLeagues(): Promise<League[]> {
    return await db.select().from(leagues).where(eq(leagues.isActive, true));
  }

  async getLeague(id: string): Promise<League | undefined> {
    const [league] = await db.select().from(leagues).where(eq(leagues.id, id));
    return league || undefined;
  }

  async createLeague(insertLeague: InsertLeague): Promise<League> {
    const [league] = await db.insert(leagues).values(insertLeague).returning();
    return league;
  }

  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams);
  }

  async getTeamsByLeague(leagueId: string): Promise<Team[]> {
    return await db.select().from(teams).where(eq(teams.leagueId, leagueId));
  }

  async getTeam(id: string): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team || undefined;
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const [team] = await db.insert(teams).values(insertTeam).returning();
    return team;
  }

  async getUpcomingMatches(limit: number = 50): Promise<MatchWithDetails[]> {
    const now = new Date();
    const matchResults = await db
      .select()
      .from(matches)
      .where(gte(matches.kickoffTime, now))
      .orderBy(matches.kickoffTime)
      .limit(limit);

    const enrichedMatches: MatchWithDetails[] = [];
    
    for (const match of matchResults) {
      const [homeTeam, awayTeam, league] = await Promise.all([
        db.select().from(teams).where(eq(teams.id, match.homeTeamId)).then(r => r[0]),
        db.select().from(teams).where(eq(teams.id, match.awayTeamId)).then(r => r[0]),
        db.select().from(leagues).where(eq(leagues.id, match.leagueId)).then(r => r[0])
      ]);

      if (homeTeam && awayTeam && league) {
        enrichedMatches.push({
          ...match,
          homeTeam,
          awayTeam,
          league,
          predictions: [],
          odds: [],
        });
      }
    }
    
    return enrichedMatches;
  }

  async getMatchesByLeague(leagueId: string, upcoming: boolean = true): Promise<MatchWithDetails[]> {
    const now = new Date();
    const condition = upcoming 
      ? and(eq(matches.leagueId, leagueId), gte(matches.kickoffTime, now))
      : eq(matches.leagueId, leagueId);

    const matchResults = await db
      .select()
      .from(matches)
      .where(condition)
      .orderBy(matches.kickoffTime);

    const enrichedMatches: MatchWithDetails[] = [];
    
    for (const match of matchResults) {
      const [homeTeam, awayTeam, league] = await Promise.all([
        db.select().from(teams).where(eq(teams.id, match.homeTeamId)).then(r => r[0]),
        db.select().from(teams).where(eq(teams.id, match.awayTeamId)).then(r => r[0]),
        db.select().from(leagues).where(eq(leagues.id, match.leagueId)).then(r => r[0])
      ]);

      if (homeTeam && awayTeam && league) {
        enrichedMatches.push({
          ...match,
          homeTeam,
          awayTeam,
          league,
          predictions: [],
          odds: [],
        });
      }
    }
    
    return enrichedMatches;
  }

  async getMatch(id: string): Promise<MatchWithDetails | undefined> {
    const [match] = await db
      .select()
      .from(matches)
      .where(eq(matches.id, id))
      .limit(1);

    if (!match) return undefined;

    const [homeTeam, awayTeam, league] = await Promise.all([
      db.select().from(teams).where(eq(teams.id, match.homeTeamId)).then(r => r[0]),
      db.select().from(teams).where(eq(teams.id, match.awayTeamId)).then(r => r[0]),
      db.select().from(leagues).where(eq(leagues.id, match.leagueId)).then(r => r[0])
    ]);

    if (!homeTeam || !awayTeam || !league) return undefined;

    return {
      ...match,
      homeTeam,
      awayTeam,
      league,
      predictions: [],
      odds: [],
    };
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const [match] = await db.insert(matches).values(insertMatch).returning();
    return match;
  }

  async updateMatch(id: string, updates: Partial<InsertMatch>): Promise<Match | undefined> {
    const [match] = await db
      .update(matches)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(matches.id, id))
      .returning();
    return match || undefined;
  }

  async getPredictionsForMatch(matchId: string): Promise<Prediction[]> {
    return await db.select().from(predictions).where(eq(predictions.matchId, matchId));
  }

  async getHighConfidencePredictions(minConfidence: number = 75): Promise<Prediction[]> {
    return await db
      .select()
      .from(predictions)
      .where(gte(predictions.confidence, sql`${minConfidence}`))
      .orderBy(desc(predictions.confidence));
  }

  async createPrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const [prediction] = await db.insert(predictions).values(insertPrediction).returning();
    return prediction;
  }

  async getOddsForMatch(matchId: string): Promise<Odds[]> {
    return await db.select().from(odds).where(eq(odds.matchId, matchId));
  }

  async createOdds(insertOdds: InsertOdds): Promise<Odds> {
    const [oddsRecord] = await db.insert(odds).values(insertOdds).returning();
    return oddsRecord;
  }

  async updateOdds(id: string, updates: Partial<InsertOdds>): Promise<Odds | undefined> {
    const [oddsRecord] = await db
      .update(odds)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(odds.id, id))
      .returning();
    return oddsRecord || undefined;
  }

  async getTeamStats(teamId: string, season?: string): Promise<TeamStats | undefined> {
    const condition = season 
      ? and(eq(teamStats.teamId, teamId), eq(teamStats.season, season))
      : eq(teamStats.teamId, teamId);
    
    const [stats] = await db
      .select()
      .from(teamStats)
      .where(condition)
      .orderBy(desc(teamStats.updatedAt))
      .limit(1);
    
    return stats || undefined;
  }

  async createOrUpdateTeamStats(insertStats: InsertTeamStats): Promise<TeamStats> {
    const existing = await db
      .select()
      .from(teamStats)
      .where(
        and(
          eq(teamStats.teamId, insertStats.teamId),
          eq(teamStats.season, insertStats.season)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      const [updated] = await db
        .update(teamStats)
        .set({ ...insertStats, updatedAt: new Date() })
        .where(eq(teamStats.id, existing[0].id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(teamStats).values(insertStats).returning();
      return created;
    }
  }

  async getActiveInjuries(teamId: string): Promise<Injury[]> {
    const now = new Date();
    return await db
      .select()
      .from(injuries)
      .where(
        and(
          eq(injuries.teamId, teamId),
          gte(injuries.expectedReturn, now)
        )
      );
  }

  async createInjury(insertInjury: InsertInjury): Promise<Injury> {
    const [injury] = await db.insert(injuries).values(insertInjury).returning();
    return injury;
  }
}

export const storage = new DatabaseStorage();
