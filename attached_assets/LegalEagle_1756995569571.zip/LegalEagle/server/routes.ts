import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ScrapingService } from "./services/scraper";
import { MLService } from "./services/ml-service";
import { SchedulerService } from "./services/scheduler";
import { insertLeagueSchema, insertTeamSchema, insertMatchSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const scrapingService = new ScrapingService();
  const mlService = new MLService();
  const schedulerService = new SchedulerService(scrapingService, mlService, storage);

  // Start background services
  schedulerService.start();

  // Health check
  app.get("/api/health", async (req, res) => {
    try {
      const stats = {
        status: "healthy",
        timestamp: new Date().toISOString(),
        services: {
          database: "connected",
          scraper: scrapingService.isHealthy() ? "active" : "inactive",
          ml: "ready",
          scheduler: schedulerService.isRunning() ? "active" : "inactive",
        }
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        status: "unhealthy", 
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Dashboard statistics
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const upcomingMatches = await storage.getUpcomingMatches(200);
      const highConfidencePredictions = await storage.getHighConfidencePredictions(75);
      
      const stats = {
        upcomingMatchesCount: upcomingMatches.length,
        highConfidenceCount: highConfidencePredictions.length,
        modelAccuracy: 73.2, // This would be calculated from historical predictions
        dataFreshness: Math.floor(Math.random() * 5) + 1, // Minutes since last update
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch dashboard stats" 
      });
    }
  });

  // Leagues
  app.get("/api/leagues", async (req, res) => {
    try {
      const leagues = await storage.getLeagues();
      res.json(leagues);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch leagues" 
      });
    }
  });

  app.post("/api/leagues", async (req, res) => {
    try {
      const validatedData = insertLeagueSchema.parse(req.body);
      const league = await storage.createLeague(validatedData);
      res.status(201).json(league);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Invalid league data" 
      });
    }
  });

  // Matches
  app.get("/api/matches/upcoming", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const matches = await storage.getUpcomingMatches(limit);
      
      // Enrich with predictions and odds
      const enrichedMatches = await Promise.all(
        matches.map(async (match) => {
          const [predictions, odds] = await Promise.all([
            storage.getPredictionsForMatch(match.id),
            storage.getOddsForMatch(match.id),
          ]);
          return { ...match, predictions, odds };
        })
      );

      res.json(enrichedMatches);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch upcoming matches" 
      });
    }
  });

  app.get("/api/matches/league/:leagueId", async (req, res) => {
    try {
      const { leagueId } = req.params;
      const matches = await storage.getMatchesByLeague(leagueId, true);
      
      // Enrich with predictions and odds
      const enrichedMatches = await Promise.all(
        matches.map(async (match) => {
          const [predictions, odds] = await Promise.all([
            storage.getPredictionsForMatch(match.id),
            storage.getOddsForMatch(match.id),
          ]);
          return { ...match, predictions, odds };
        })
      );

      res.json(enrichedMatches);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch league matches" 
      });
    }
  });

  app.get("/api/matches/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const match = await storage.getMatch(id);
      
      if (!match) {
        return res.status(404).json({ error: "Match not found" });
      }

      // Enrich with predictions, odds, and team stats
      const [predictions, odds, homeStats, awayStats] = await Promise.all([
        storage.getPredictionsForMatch(match.id),
        storage.getOddsForMatch(match.id),
        storage.getTeamStats(match.homeTeamId, "2024/25"),
        storage.getTeamStats(match.awayTeamId, "2024/25"),
      ]);

      const enrichedMatch = {
        ...match,
        predictions,
        odds,
        homeTeamStats: homeStats,
        awayTeamStats: awayStats,
      };

      res.json(enrichedMatch);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch match details" 
      });
    }
  });

  app.post("/api/matches", async (req, res) => {
    try {
      const validatedData = insertMatchSchema.parse(req.body);
      const match = await storage.createMatch(validatedData);
      res.status(201).json(match);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Invalid match data" 
      });
    }
  });

  // High confidence predictions
  app.get("/api/predictions/high-confidence", async (req, res) => {
    try {
      const minConfidence = req.query.minConfidence 
        ? parseFloat(req.query.minConfidence as string) 
        : 75;
      
      const predictions = await storage.getHighConfidencePredictions(minConfidence);
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to fetch high confidence predictions" 
      });
    }
  });

  // Trigger manual scraping (for testing/debugging)
  app.post("/api/scrape/manual", async (req, res) => {
    try {
      const { source, league } = req.body;
      
      if (source === "fixtures") {
        await scrapingService.scrapeFixtures();
      } else if (source === "odds") {
        await scrapingService.scrapeOdds();
      } else {
        await scrapingService.scrapeAll();
      }
      
      res.json({ message: "Scraping initiated", source });
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to initiate scraping" 
      });
    }
  });

  // Generate predictions for a match
  app.post("/api/predictions/generate/:matchId", async (req, res) => {
    try {
      const { matchId } = req.params;
      const match = await storage.getMatch(matchId);
      
      if (!match) {
        return res.status(404).json({ error: "Match not found" });
      }

      const predictions = await mlService.generatePredictions(match);
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to generate predictions" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
