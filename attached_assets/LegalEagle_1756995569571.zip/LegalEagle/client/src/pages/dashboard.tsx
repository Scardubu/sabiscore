import { useQuery } from "@tanstack/react-query";
import { LeagueSidebar } from "@/components/league-sidebar";
import { StatsHeader } from "@/components/stats-header";
import { MatchCard } from "@/components/match-card";
import { PredictionModal } from "@/components/prediction-modal";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Eye, Bookmark, Filter } from "lucide-react";
import type { MatchWithDetails } from "@shared/schema";

export default function Dashboard() {
  const [selectedLeague, setSelectedLeague] = useState<string>("all");
  const [selectedMatch, setSelectedMatch] = useState<MatchWithDetails | null>(null);
  const [sortBy, setSortBy] = useState<string>("confidence");
  const [currentPage, setCurrentPage] = useState(1);
  const matchesPerPage = 10;

  const { data: dashboardStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: upcomingMatches, isLoading: matchesLoading } = useQuery({
    queryKey: ["/api/matches/upcoming"],
  });

  const { data: highConfidenceMatches, isLoading: highConfidenceLoading } = useQuery({
    queryKey: ["/api/predictions/high-confidence"],
  });

  const filteredMatches = (upcomingMatches as MatchWithDetails[] || []).filter((match: MatchWithDetails) => 
    selectedLeague === "all" || match.league.id === selectedLeague
  );

  const sortedMatches = [...filteredMatches].sort((a, b) => {
    if (sortBy === "confidence") {
      const aConf = Math.max(...(a.predictions?.map((p: any) => Number(p.confidence)) || [0]));
      const bConf = Math.max(...(b.predictions?.map((p: any) => Number(p.confidence)) || [0]));
      return bConf - aConf;
    } else if (sortBy === "date") {
      return new Date(a.kickoffTime).getTime() - new Date(b.kickoffTime).getTime();
    }
    return 0;
  });

  const paginatedMatches = sortedMatches.slice(
    (currentPage - 1) * matchesPerPage,
    currentPage * matchesPerPage
  );

  const totalPages = Math.ceil(sortedMatches.length / matchesPerPage);

  const handleMatchClick = (match: MatchWithDetails) => {
    setSelectedMatch(match);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <i className="fas fa-chess-king text-primary text-2xl"></i>
                <span className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  LegalEagle AI
                </span>
              </div>
              <div className="hidden md:flex items-center space-x-1 px-3 py-1 bg-muted rounded-full text-sm">
                <div className="w-2 h-2 bg-secondary rounded-full pulse-dot"></div>
                <span className="text-muted-foreground">Live Data</span>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#" className="text-foreground hover:text-primary transition-colors" data-testid="nav-dashboard">
                Dashboard
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-analytics">
                Analytics
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-models">
                Models
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-settings">
                Settings
              </a>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="p-2" data-testid="button-notifications">
                <i className="fas fa-bell"></i>
              </Button>
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <i className="fas fa-user text-primary-foreground text-sm"></i>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex min-h-screen">
        {/* Sidebar */}
        <LeagueSidebar
          selectedLeague={selectedLeague}
          onLeagueSelect={setSelectedLeague}
        />

        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="max-w-6xl mx-auto space-y-6">
            {/* Stats Header */}
            <StatsHeader stats={dashboardStats as any} loading={statsLoading} />

            {/* High Confidence Predictions */}
            <Card className="bg-card border-border">
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold" data-testid="text-high-confidence-title">
                    High-Confidence Predictions
                  </h2>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <i className="fas fa-shield-alt text-secondary"></i>
                    <span>AI-Verified</span>
                  </div>
                </div>
              </div>
              
              <div className="p-6 space-y-4">
                {highConfidenceLoading ? (
                  <div className="space-y-4">
                    {[1, 2].map((i) => (
                      <div key={i} className="h-32 bg-muted/30 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : (
                  (upcomingMatches as MatchWithDetails[] || []).slice(0, 2).map((match: MatchWithDetails) => (
                    <MatchCard
                      key={match.id}
                      match={match}
                      featured
                      onClick={() => handleMatchClick(match)}
                    />
                  ))
                )}
              </div>
            </Card>

            {/* All Upcoming Matches */}
            <Card className="bg-card border-border">
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold" data-testid="text-all-matches-title">
                    All Upcoming Matches
                  </h2>
                  <div className="flex items-center space-x-3">
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-48" data-testid="select-sort">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="confidence">Sort by Confidence</SelectItem>
                        <SelectItem value="date">Sort by Date</SelectItem>
                        <SelectItem value="league">Sort by League</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <Filter className="w-4 h-4" />
                      <span data-testid="text-matches-count">{sortedMatches.length} matches</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-muted/30">
                    <tr className="text-left text-sm text-muted-foreground">
                      <th className="p-4">Match</th>
                      <th className="p-4">League</th>
                      <th className="p-4">Date</th>
                      <th className="p-4">Prediction</th>
                      <th className="p-4">Confidence</th>
                      <th className="p-4">xG</th>
                      <th className="p-4">Best Odds</th>
                      <th className="p-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    {matchesLoading ? (
                      Array.from({ length: matchesPerPage }).map((_, i) => (
                        <tr key={i} className="border-b border-border">
                          <td className="p-4">
                            <div className="h-6 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                          <td className="p-4">
                            <div className="h-4 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                          <td className="p-4">
                            <div className="h-4 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                          <td className="p-4">
                            <div className="h-4 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                          <td className="p-4">
                            <div className="h-4 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                          <td className="p-4">
                            <div className="h-4 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                          <td className="p-4">
                            <div className="h-4 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                          <td className="p-4">
                            <div className="h-4 bg-muted/30 rounded animate-pulse shimmer" />
                          </td>
                        </tr>
                      ))
                    ) : (
                      paginatedMatches.map((match: MatchWithDetails) => {
                        const bestPrediction = match.predictions?.[0];
                        const bestOdds = match.odds?.[0];
                        const confidence = bestPrediction ? Number(bestPrediction.confidence) : 0;
                        
                        return (
                          <tr key={match.id} className="border-b border-border hover:bg-muted/20 transition-all duration-300 hover:scale-[1.01]" data-testid={`row-match-${match.id}`}>
                            <td className="p-4">
                              <div className="flex items-center space-x-3">
                                <div className="flex items-center space-x-2">
                                  <img 
                                    src={match.homeTeam.logoUrl || "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=24&h=24"} 
                                    alt={match.homeTeam.name} 
                                    className="w-6 h-6 rounded-full"
                                    data-testid={`img-team-${match.homeTeam.id}`}
                                  />
                                  <span className="font-medium" data-testid={`text-home-team-${match.id}`}>
                                    {match.homeTeam.name}
                                  </span>
                                </div>
                                <span className="text-muted-foreground">vs</span>
                                <div className="flex items-center space-x-2">
                                  <img 
                                    src={match.awayTeam.logoUrl || "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=24&h=24"} 
                                    alt={match.awayTeam.name} 
                                    className="w-6 h-6 rounded-full"
                                    data-testid={`img-team-${match.awayTeam.id}`}
                                  />
                                  <span className="font-medium" data-testid={`text-away-team-${match.id}`}>
                                    {match.awayTeam.name}
                                  </span>
                                </div>
                              </div>
                            </td>
                            <td className="p-4">
                              <span className="text-muted-foreground" data-testid={`text-league-${match.id}`}>
                                {match.league.name}
                              </span>
                            </td>
                            <td className="p-4">
                              <div className="text-foreground" data-testid={`text-date-${match.id}`}>
                                {new Date(match.kickoffTime).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                              </div>
                              <div className="text-xs text-muted-foreground" data-testid={`text-time-${match.id}`}>
                                {new Date(match.kickoffTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </td>
                            <td className="p-4">
                              {bestPrediction ? (
                                <div className="flex items-center space-x-1">
                                  <div className={`w-2 h-2 rounded-full ${
                                    bestPrediction.outcome === 'home_win' ? 'bg-primary' :
                                    bestPrediction.outcome === 'away_win' ? 'bg-primary' :
                                    'bg-secondary'
                                  }`} />
                                  <span className={`font-medium ${
                                    bestPrediction.outcome === 'home_win' ? 'text-primary' :
                                    bestPrediction.outcome === 'away_win' ? 'text-primary' :
                                    'text-secondary'
                                  }`} data-testid={`text-prediction-${match.id}`}>
                                    {bestPrediction.outcome === 'home_win' ? 'Home Win' :
                                     bestPrediction.outcome === 'away_win' ? 'Away Win' :
                                     'Draw'}
                                  </span>
                                </div>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </td>
                            <td className="p-4">
                              {bestPrediction ? (
                                <div className="flex items-center space-x-2">
                                  <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                                    <div 
                                      className="h-full confidence-bar rounded-full"
                                      style={{ width: `${confidence}%` }}
                                    />
                                  </div>
                                  <span className="text-xs font-mono" data-testid={`text-confidence-${match.id}`}>
                                    {Number(bestPrediction.confidence).toFixed(0)}%
                                  </span>
                                </div>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </td>
                            <td className="p-4">
                              <span className="font-mono text-xs" data-testid={`text-xg-${match.id}`}>
                                {match.homeXg && match.awayXg ? 
                                  `${Number(match.homeXg).toFixed(1)} - ${Number(match.awayXg).toFixed(1)}` : 
                                  "-"}
                              </span>
                            </td>
                            <td className="p-4">
                              <span className="font-mono text-accent font-medium" data-testid={`text-odds-${match.id}`}>
                                {bestOdds?.homeOdds ? Number(bestOdds.homeOdds).toFixed(2) : "-"}
                              </span>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleMatchClick(match)}
                                  data-testid={`button-view-details-${match.id}`}
                                >
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  data-testid={`button-bookmark-${match.id}`}
                                >
                                  <Bookmark className="w-4 h-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
              
              {/* Pagination */}
              <div className="p-4 border-t border-border flex items-center justify-between">
                <div className="text-sm text-muted-foreground" data-testid="text-pagination-info">
                  Showing {(currentPage - 1) * matchesPerPage + 1}-{Math.min(currentPage * matchesPerPage, sortedMatches.length)} of {sortedMatches.length} matches
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                    data-testid="button-previous-page"
                  >
                    <ChevronLeft className="w-4 h-4 mr-1" />
                    Previous
                  </Button>
                  
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    const page = i + 1;
                    return (
                      <Button
                        key={page}
                        variant={currentPage === page ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(page)}
                        data-testid={`button-page-${page}`}
                      >
                        {page}
                      </Button>
                    );
                  })}
                  
                  {totalPages > 5 && (
                    <>
                      <span className="text-muted-foreground">...</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(totalPages)}
                        data-testid={`button-page-${totalPages}`}
                      >
                        {totalPages}
                      </Button>
                    </>
                  )}
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    disabled={currentPage === totalPages}
                    data-testid="button-next-page"
                  >
                    Next
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </main>
      </div>

      {/* Prediction Modal */}
      {selectedMatch && (
        <PredictionModal
          match={selectedMatch}
          onClose={() => setSelectedMatch(null)}
        />
      )}
    </div>
  );
}
