import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, BarChart3, AlertTriangle, X, Target, Zap, Clock } from "lucide-react";
import { BettingMarkets } from "./betting-markets";
import type { MatchWithDetails } from "@shared/schema";

interface PredictionModalProps {
  match: MatchWithDetails;
  onClose: () => void;
}

export function PredictionModal({ match, onClose }: PredictionModalProps) {
  const bestPrediction = match.predictions?.[0];
  const features = bestPrediction?.features as any;

  const getRiskFactors = () => [
    "Weather conditions may affect play style (rain expected)",
    "High-pressure match could lead to tactical caution",
    "Key player availability uncertain until 24h before match",
  ];

  return (
    <Dialog open={true} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden bg-card border-border" data-testid="modal-prediction-explanation">
        <DialogHeader className="pb-4 border-b border-border">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold" data-testid="text-modal-title">
              AI Analysis Dashboard
            </DialogTitle>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClose}
              data-testid="button-close-modal"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex items-center justify-between mt-2">
            <div className="text-sm text-muted-foreground" data-testid="text-modal-subtitle">
              {match.homeTeam.name} vs {match.awayTeam.name}
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="bg-primary/10 border-primary/20">
                <Zap className="w-3 h-3 mr-1" />
                Live Analysis
              </Badge>
              <Badge variant="outline" className="bg-secondary/10 border-secondary/20">
                <Clock className="w-3 h-3 mr-1" />
                Updated 2 min ago
              </Badge>
            </div>
          </div>
        </DialogHeader>
        
        <Tabs defaultValue="overview" className="h-full">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <Brain className="w-4 h-4" />
              <span>AI Reasoning</span>
            </TabsTrigger>
            <TabsTrigger value="markets" className="flex items-center space-x-2">
              <Target className="w-4 h-4" />
              <span>Betting Markets</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4" />
              <span>Deep Analytics</span>
            </TabsTrigger>
          </TabsList>

          <div className="overflow-y-auto max-h-[calc(85vh-180px)]">
            <TabsContent value="overview" className="space-y-6 mt-0">
          {bestPrediction ? (
            <>
              <div>
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Brain className="w-5 h-5 text-primary" />
                  <span>Model Reasoning</span>
                </h4>
                <Card className="bg-muted/30 p-4">
                  <p className="mb-3 text-sm" data-testid="text-prediction-summary">
                    The model predicts a <strong className="text-secondary">
                      {bestPrediction.outcome === "home_win" ? "Home Win" :
                       bestPrediction.outcome === "away_win" ? "Away Win" :
                       "Draw"} ({Number(bestPrediction.confidence).toFixed(0)}% confidence)
                    </strong> based on the following factors:
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start space-x-2">
                      <span className="text-secondary mt-0.5">•</span>
                      <span>
                        <strong>Head-to-head record:</strong> Historical performance analysis from recent meetings
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="text-secondary mt-0.5">•</span>
                      <span>
                        <strong>Current form:</strong> Both teams' recent performance trajectory
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="text-secondary mt-0.5">•</span>
                      <span>
                        <strong>Expected Goals (xG):</strong> Advanced attacking and defensive metrics
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="text-secondary mt-0.5">•</span>
                      <span>
                        <strong>Squad availability:</strong> Injury reports and team strength analysis
                      </span>
                    </li>
                  </ul>
                </Card>
              </div>

              <div>
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-accent" />
                  <span>Feature Importance</span>
                </h4>
                <div className="space-y-3">
                  {features?.importance && Object.entries(features.importance).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between" data-testid={`feature-importance-${key}`}>
                      <span className="text-sm capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </span>
                      <div className="flex items-center space-x-2">
                        <Progress value={value as number} className="w-20 h-2" />
                        <span className="text-xs font-mono w-8">{value as number}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-accent" />
                  <span>Risk Factors</span>
                </h4>
                <Card className="bg-accent/10 border-accent/20 p-4">
                  <ul className="text-sm space-y-2 text-accent-foreground">
                    {getRiskFactors().map((risk, index) => (
                      <li key={index} className="flex items-start space-x-2" data-testid={`risk-factor-${index}`}>
                        <AlertTriangle className="w-3 h-3 text-accent mt-0.5 flex-shrink-0" />
                        <span>{risk}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div className="text-xs text-muted-foreground" data-testid="text-model-info">
                  Model: {bestPrediction.modelVersion} | Last trained: 2 hours ago | Calibrated: Yes
                </div>
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-full-analysis">
                  View Full Analysis
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="text-muted-foreground mb-4">
                <Brain className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No predictions available for this match yet.</p>
              </div>
              <Button variant="outline" data-testid="button-generate-prediction">
                Generate Prediction
              </Button>
            </div>
          )}
            </TabsContent>

            <TabsContent value="markets" className="space-y-6 mt-0">
              <BettingMarkets 
                predictions={match.predictions || []} 
                odds={match.odds?.[0]} 
                matchId={match.id}
              />
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6 mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-4">
                  <h4 className="font-medium mb-3 flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    <span>Team Comparison</span>
                  </h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <span>Attack Strength</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary w-3/4"></div>
                        </div>
                        <span className="text-xs w-8">75%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Defense Solidity</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-secondary w-4/5"></div>
                        </div>
                        <span className="text-xs w-8">80%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Recent Form</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-accent w-3/5"></div>
                        </div>
                        <span className="text-xs w-8">60%</span>
                      </div>
                    </div>
                  </div>
                </Card>

                <Card className="p-4">
                  <h4 className="font-medium mb-3 flex items-center space-x-2">
                    <Target className="w-5 h-5 text-secondary" />
                    <span>Market Sentiment</span>
                  </h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Public Money</span>
                      <Badge variant="outline" className="bg-green-500/20 text-green-400">
                        65% Home
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Sharp Money</span>
                      <Badge variant="outline" className="bg-blue-500/20 text-blue-400">
                        58% Away
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Line Movement</span>
                      <Badge variant="outline" className="bg-red-500/20 text-red-400">
                        -0.5 pts
                      </Badge>
                    </div>
                  </div>
                </Card>
              </div>

              <Card className="p-4">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-accent" />
                  <span>Real-time Factors</span>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="font-medium text-muted-foreground">Weather</div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                      <span>Partly cloudy, 18°C</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="font-medium text-muted-foreground">Injuries</div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                      <span>2 key players out</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="font-medium text-muted-foreground">Motivation</div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span>High stakes match</span>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
