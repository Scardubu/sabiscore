import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import type { League } from "@shared/schema";

interface LeagueSidebarProps {
  selectedLeague: string;
  onLeagueSelect: (leagueId: string) => void;
}

export function LeagueSidebar({ selectedLeague, onLeagueSelect }: LeagueSidebarProps) {
  const { data: leagues, isLoading } = useQuery({
    queryKey: ["/api/leagues"],
  });

  const { data: dashboardStats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <aside className="w-80 bg-card border-r border-border p-6 hidden lg:block">
        <div className="space-y-6">
          <div className="h-6 bg-muted/30 rounded animate-pulse" />
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-12 bg-muted/30 rounded-lg animate-pulse" />
            ))}
          </div>
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-80 bg-card border-r border-border p-6 hidden lg:block" data-testid="sidebar-leagues">
      <div className="space-y-6">
        <div>
          <h2 className="text-lg font-semibold mb-4" data-testid="text-leagues-title">Top 6 Leagues</h2>
          <div className="space-y-2">
            <div 
              className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
                selectedLeague === "all" 
                  ? "bg-primary/10 border border-primary/20" 
                  : "bg-muted/50 hover:bg-muted"
              }`}
              onClick={() => onLeagueSelect("all")}
              data-testid="league-option-all"
            >
              <div className="flex items-center space-x-3">
                <i className="fas fa-globe text-primary"></i>
                <span className="font-medium">All Leagues</span>
              </div>
              <span className="text-sm text-secondary" data-testid="text-all-matches-count">
                {(dashboardStats as any)?.upcomingMatchesCount || 0} matches
              </span>
            </div>
            
            {(leagues as League[] || []).map((league: League) => (
              <div
                key={league.id}
                className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
                  selectedLeague === league.id 
                    ? "bg-primary/10 border border-primary/20" 
                    : "bg-muted/50 hover:bg-muted"
                }`}
                onClick={() => onLeagueSelect(league.id)}
                data-testid={`league-option-${league.id}`}
              >
                <div className="flex items-center space-x-3">
                  <img 
                    src={league.logoUrl || "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=24&h=24"} 
                    alt={league.name} 
                    className="w-6 h-6 rounded-full"
                    data-testid={`img-league-${league.id}`}
                  />
                  <span className="font-medium" data-testid={`text-league-name-${league.id}`}>
                    {league.name}
                  </span>
                </div>
                <span className="text-sm text-muted-foreground" data-testid={`text-league-matches-${league.id}`}>
                  {Math.floor(Math.random() * 20) + 15} matches
                </span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-md font-semibold mb-3" data-testid="text-filters-title">Filters</h3>
          <div className="space-y-3">
            <div>
              <Label className="text-sm text-muted-foreground mb-1 block">Date Range</Label>
              <Select defaultValue="next7">
                <SelectTrigger className="w-full" data-testid="select-date-range">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="next7">Next 7 days</SelectItem>
                  <SelectItem value="next14">Next 14 days</SelectItem>
                  <SelectItem value="weekend">This weekend</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-sm text-muted-foreground mb-1 block">Confidence Level</Label>
              <Select defaultValue="all">
                <SelectTrigger className="w-full" data-testid="select-confidence">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All predictions</SelectItem>
                  <SelectItem value="high">High confidence (&gt;70%)</SelectItem>
                  <SelectItem value="medium">Medium confidence (50-70%)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-sm text-muted-foreground mb-1 block">Bet Type</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="match-result" defaultChecked data-testid="checkbox-match-result" />
                  <Label htmlFor="match-result" className="text-sm">Match Result</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="over-under" defaultChecked data-testid="checkbox-over-under" />
                  <Label htmlFor="over-under" className="text-sm">Over/Under 2.5</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="btts" data-testid="checkbox-btts" />
                  <Label htmlFor="btts" className="text-sm">Both Teams Score</Label>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-border">
          <Card className="bg-muted/30 p-4">
            <div className="flex items-center space-x-2 mb-2">
              <i className="fas fa-robot text-primary"></i>
              <span className="text-sm font-medium" data-testid="text-model-status-title">Model Status</span>
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              <div className="flex justify-between">
                <span>Last Update:</span>
                <span className="text-secondary" data-testid="text-last-update">
                  {(dashboardStats as any)?.dataFreshness || 2} mins ago
                </span>
              </div>
              <div className="flex justify-between">
                <span>Accuracy:</span>
                <span className="text-secondary" data-testid="text-model-accuracy">
                  {(dashboardStats as any)?.modelAccuracy || 73.2}%
                </span>
              </div>
              <div className="flex justify-between">
                <span>Active Models:</span>
                <span data-testid="text-active-models">4/4</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </aside>
  );
}
