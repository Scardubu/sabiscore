import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, Target, Clock, AlertTriangle, Star } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface BettingMarketsProps {
  predictions: any[];
  odds?: any;
  matchId: string;
}

export function BettingMarkets({ predictions, odds, matchId }: BettingMarketsProps) {
  const getMarketIcon = (type: string) => {
    switch (type) {
      case "match_result": return <Target className="w-4 h-4" />;
      case "over_under": return <TrendingUp className="w-4 h-4" />;
      case "btts": return <Star className="w-4 h-4" />;
      case "corners": return <Clock className="w-4 h-4" />;
      case "cards": return <AlertTriangle className="w-4 h-4" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  const getMarketName = (type: string) => {
    switch (type) {
      case "match_result": return "Match Result";
      case "over_under": return "Over/Under 2.5";
      case "btts": return "Both Teams Score";
      case "corners": return "Corners O/U 9.5";
      case "cards": return "Cards O/U 3.5";
      default: return type;
    }
  };

  const getRiskLevelColor = (risk: string) => {
    switch (risk) {
      case "low": return "bg-green-500/20 text-green-400 border-green-500/30";
      case "medium": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      case "high": return "bg-red-500/20 text-red-400 border-red-500/30";
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  const getExpectedValueColor = (ev: number) => {
    if (ev > 0.1) return "text-green-400";
    if (ev > 0) return "text-blue-400";
    return "text-red-400";
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center space-x-2">
          <Target className="w-5 h-5 text-primary" />
          <span>Betting Markets</span>
        </h3>
        <Badge variant="outline" className="bg-primary/10 border-primary/20">
          {predictions.length} Markets
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {predictions.map((prediction, index) => {
          const expectedValue = parseFloat(prediction.expectedValue || "0");
          const confidence = parseFloat(prediction.confidence || "0");
          const probability = parseFloat(prediction.probability || "0");

          return (
            <Card 
              key={`${prediction.predictionType}-${index}`}
              className="p-4 border-border bg-card/50 hover:bg-card transition-all duration-200 group"
              data-testid={`card-market-${prediction.predictionType}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    {getMarketIcon(prediction.predictionType)}
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">{getMarketName(prediction.predictionType)}</h4>
                    <p className="text-xs text-muted-foreground">AI Prediction</p>
                  </div>
                </div>
                <Badge 
                  className={`text-xs px-2 py-1 ${getRiskLevelColor(prediction.riskLevel || "medium")}`}
                  data-testid={`badge-risk-${prediction.predictionType}`}
                >
                  {prediction.riskLevel || "medium"} risk
                </Badge>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Prediction:</span>
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-sm">
                      {prediction.outcome.replace("_", " ").toUpperCase()}
                    </span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger>
                          <div className="w-2 h-2 bg-secondary rounded-full"></div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Model Version: {prediction.modelVersion}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Confidence:</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-500"
                        style={{ width: `${confidence}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium">{confidence.toFixed(0)}%</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Probability:</span>
                  <span className="text-sm font-medium">{probability.toFixed(1)}%</span>
                </div>

                {expectedValue !== 0 && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Expected Value:</span>
                    <div className="flex items-center space-x-1">
                      {expectedValue > 0 ? (
                        <TrendingUp className="w-3 h-3 text-green-400" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-400" />
                      )}
                      <span className={`text-sm font-medium ${getExpectedValueColor(expectedValue)}`}>
                        {expectedValue > 0 ? "+" : ""}{expectedValue.toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}

                {prediction.marketVolume && (
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>Market Volume:</span>
                    <span>${(parseFloat(prediction.marketVolume) / 1000000).toFixed(1)}M</span>
                  </div>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-border">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-xs group-hover:bg-primary/10 group-hover:border-primary/30 transition-all"
                  data-testid={`button-analyze-${prediction.predictionType}`}
                >
                  <Target className="w-3 h-3 mr-1" />
                  Analyze Market
                </Button>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}