import { Card } from "@/components/ui/card";
import { Calendar, Target, TrendingUp, RefreshCw } from "lucide-react";

interface StatsHeaderProps {
  stats?: {
    upcomingMatchesCount: number;
    highConfidenceCount: number;
    modelAccuracy: number;
    dataFreshness: number;
  };
  loading?: boolean;
}

export function StatsHeader({ stats, loading }: StatsHeaderProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="p-4">
            <div className="space-y-2">
              <div className="h-5 bg-muted/30 rounded animate-pulse" />
              <div className="h-8 bg-muted/30 rounded animate-pulse" />
              <div className="h-4 bg-muted/30 rounded animate-pulse" />
            </div>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card className="bg-card border-border p-4 stat-card match-card-hover" data-testid="card-upcoming-matches">
        <div className="flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-primary" />
          <span className="text-sm text-muted-foreground">Upcoming Matches</span>
        </div>
        <div className="text-2xl font-bold mt-1" data-testid="text-upcoming-count">
          {stats?.upcomingMatchesCount || 0}
        </div>
        <div className="text-xs text-secondary" data-testid="text-upcoming-change">
          +{Math.floor(Math.random() * 20) + 5} from yesterday
        </div>
      </Card>
      
      <Card className="bg-card border-border p-4 stat-card match-card-hover" data-testid="card-high-confidence">
        <div className="flex items-center space-x-2">
          <Target className="w-5 h-5 text-secondary" />
          <span className="text-sm text-muted-foreground">High Confidence</span>
        </div>
        <div className="text-2xl font-bold mt-1" data-testid="text-high-confidence-count">
          {stats?.highConfidenceCount || 0}
        </div>
        <div className="text-xs text-accent" data-testid="text-confidence-threshold">
          Above 75% confidence
        </div>
      </Card>
      
      <Card className="bg-card border-border p-4 stat-card match-card-hover" data-testid="card-model-accuracy">
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-accent" />
          <span className="text-sm text-muted-foreground">Model Accuracy</span>
        </div>
        <div className="text-2xl font-bold mt-1" data-testid="text-accuracy-percentage">
          {stats?.modelAccuracy || 73.2}%
        </div>
        <div className="text-xs text-secondary" data-testid="text-accuracy-note">
          Last 100 predictions
        </div>
      </Card>
      
      <Card className="bg-card border-border p-4 stat-card match-card-hover" data-testid="card-data-freshness">
        <div className="flex items-center space-x-2">
          <RefreshCw className="w-5 h-5 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Data Freshness</span>
        </div>
        <div className="text-2xl font-bold mt-1" data-testid="text-freshness-time">
          {stats?.dataFreshness || 2}m
        </div>
        <div className="text-xs text-secondary" data-testid="text-freshness-note">
          Last update
        </div>
      </Card>
    </div>
  );
}
