import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain } from "lucide-react";
import type { MatchWithDetails } from "@shared/schema";

interface MatchCardProps {
  match: MatchWithDetails;
  featured?: boolean;
  onClick?: () => void;
}

export function MatchCard({ match, featured = false, onClick }: MatchCardProps) {
  const bestPrediction = match.predictions?.[0];
  const bestOdds = match.odds?.[0];
  const confidence = bestPrediction ? Number(bestPrediction.confidence) : 0;
  
  const getStatusIndicator = () => {
    if (Math.random() > 0.5) {
      return (
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-secondary rounded-full live-indicator" />
          <span className="text-sm font-medium text-secondary">Live Odds</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-accent rounded-full pulse-dot" />
          <span className="text-sm font-medium text-accent">Updating</span>
        </div>
      );
    }
  };

  const getPredictionOutcome = () => {
    if (!bestPrediction) return null;
    
    switch (bestPrediction.outcome) {
      case "home_win":
        return "Home Win";
      case "away_win":
        return "Away Win";
      case "draw":
        return "Draw";
      default:
        return bestPrediction.outcome;
    }
  };

  const getOddsDisplay = () => {
    if (!bestOdds) return { home: "2.10", draw: "3.40", away: "3.75" };
    
    return {
      home: bestOdds.homeOdds ? Number(bestOdds.homeOdds).toFixed(2) : "2.10",
      draw: bestOdds.drawOdds ? Number(bestOdds.drawOdds).toFixed(2) : "3.40",
      away: bestOdds.awayOdds ? Number(bestOdds.awayOdds).toFixed(2) : "3.75",
    };
  };

  const odds = getOddsDisplay();
  const isDrawPrediction = bestPrediction?.outcome === "draw";
  const isHomePrediction = bestPrediction?.outcome === "home_win";

  return (
    <Card 
      className={`${featured ? 'gradient-border shimmer' : 'border-border'} rounded-lg p-4 match-card-hover cursor-pointer relative overflow-hidden`}
      onClick={onClick}
      data-testid={`card-match-${match.id}`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-4">
          <div className="text-sm text-muted-foreground" data-testid={`text-match-time-${match.id}`}>
            {new Date(match.kickoffTime).toLocaleDateString('en-US', { 
              month: 'short', 
              day: 'numeric' 
            })} {new Date(match.kickoffTime).toLocaleTimeString('en-US', { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </div>
          {getStatusIndicator()}
        </div>
        <div className="flex items-center space-x-2">
          <span className={`text-xs px-3 py-1.5 rounded-full font-semibold ${
            confidence > 80 ? 'bg-secondary/20 text-secondary border border-secondary/30' :
            confidence > 70 ? 'bg-accent/20 text-accent border border-accent/30' :
            'bg-primary/20 text-primary border border-primary/30'
          }`} data-testid={`text-confidence-badge-${match.id}`}>
            <span className="prediction-highlight">{confidence.toFixed(0)}%</span> Confidence
          </span>
        </div>
      </div>
      
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <img 
              src={match.homeTeam.logoUrl || "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=32&h=32"} 
              alt={match.homeTeam.name} 
              className="w-8 h-8 rounded-full"
              data-testid={`img-home-team-${match.id}`}
            />
            <span className="font-semibold" data-testid={`text-home-team-name-${match.id}`}>
              {match.homeTeam.name}
            </span>
          </div>
          <span className="text-muted-foreground text-lg">vs</span>
          <div className="flex items-center space-x-3">
            <img 
              src={match.awayTeam.logoUrl || "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=32&h=32"} 
              alt={match.awayTeam.name} 
              className="w-8 h-8 rounded-full"
              data-testid={`img-away-team-${match.id}`}
            />
            <span className="font-semibold" data-testid={`text-away-team-name-${match.id}`}>
              {match.awayTeam.name}
            </span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className={`text-center ${isHomePrediction ? 'bg-secondary/10 rounded-lg py-2' : ''}`}>
          <div className="text-sm text-muted-foreground mb-1">Home Win</div>
          <div className={`text-lg font-mono ${isHomePrediction ? 'text-secondary font-bold' : 'text-primary'}`} data-testid={`text-home-odds-${match.id}`}>
            {odds.home}
          </div>
          <div className={`text-xs ${isHomePrediction ? 'text-secondary font-medium' : 'text-muted-foreground'}`}>
            {(100 / Number(odds.home)).toFixed(1)}%
          </div>
        </div>
        <div className={`text-center ${isDrawPrediction ? 'bg-secondary/10 rounded-lg py-2' : ''}`}>
          <div className="text-sm text-muted-foreground mb-1">Draw</div>
          <div className={`text-lg font-mono ${isDrawPrediction ? 'text-secondary font-bold' : 'text-primary'}`} data-testid={`text-draw-odds-${match.id}`}>
            {odds.draw}
          </div>
          <div className={`text-xs ${isDrawPrediction ? 'text-secondary font-medium' : 'text-muted-foreground'}`}>
            {(100 / Number(odds.draw)).toFixed(1)}%
          </div>
        </div>
        <div className={`text-center ${bestPrediction?.outcome === 'away_win' ? 'bg-secondary/10 rounded-lg py-2' : ''}`}>
          <div className="text-sm text-muted-foreground mb-1">Away Win</div>
          <div className={`text-lg font-mono ${bestPrediction?.outcome === 'away_win' ? 'text-secondary font-bold' : 'text-primary'}`} data-testid={`text-away-odds-${match.id}`}>
            {odds.away}
          </div>
          <div className={`text-xs ${bestPrediction?.outcome === 'away_win' ? 'text-secondary font-medium' : 'text-muted-foreground'}`}>
            {(100 / Number(odds.away)).toFixed(1)}%
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-1">
            <i className="fas fa-futbol text-muted-foreground"></i>
            <span className="text-muted-foreground">xG:</span>
            <span className="font-mono text-foreground" data-testid={`text-home-xg-${match.id}`}>
              {match.homeXg ? Number(match.homeXg).toFixed(1) : "1.8"}
            </span>
            <span className="text-muted-foreground">-</span>
            <span className="font-mono text-foreground" data-testid={`text-away-xg-${match.id}`}>
              {match.awayXg ? Number(match.awayXg).toFixed(1) : "1.2"}
            </span>
          </div>
          <div className="flex items-center space-x-1">
            <i className="fas fa-chart-bar text-muted-foreground"></i>
            <span className="text-muted-foreground">Form:</span>
            <span className="text-secondary font-medium" data-testid={`text-home-form-${match.id}`}>
              WWWDL
            </span>
            <span className="text-muted-foreground">vs</span>
            <span className="text-secondary font-medium" data-testid={`text-away-form-${match.id}`}>
              WLWWW
            </span>
          </div>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-primary hover:text-primary/80 text-sm font-medium"
          onClick={onClick}
          data-testid={`button-ai-explanation-${match.id}`}
        >
          <Brain className="w-4 h-4 mr-1" />
          AI Explanation
        </Button>
      </div>
    </Card>
  );
}
